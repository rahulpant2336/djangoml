from django.shortcuts import render

from django.http import HttpResponse

from .models import HomePageProject, Supervised, Unsupervised

# Create your views here.
def index(request):
    homepageprojects = HomePageProject.objects.all()[0:6]
    return render(request, 'mldemo/index.html', {
      'homepageprojects' : homepageprojects
    })


def supervised_category(request):
    supervisedprojectcategorys = Supervised.objects.all()
    return render(request, 'mldemo/supervised.html', {
      'supervisedprojectcategorys' : supervisedprojectcategorys
    })


def unsupervised_category(request):
    unsupervisedprojectcategorys = Unsupervised.objects.all()
    return render(request, 'mldemo/unsupervised.html', {
      'unsupervisedprojectcategorys' : unsupervisedprojectcategorys
    })


def mlprojects(request):
    supervisedprojects = Supervised.objects.all()
    unsupervisedprojects = Unsupervised.objects.all()
    return render(request, 'mldemo/allmlprojects.html', {
      'supervisedprojects' : supervisedprojects,
      'unsupervisedprojects' : unsupervisedprojects
    })

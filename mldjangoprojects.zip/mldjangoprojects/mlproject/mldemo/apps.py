from django.apps import AppConfig


class MldemoConfig(AppConfig):
    name = 'mldemo'
